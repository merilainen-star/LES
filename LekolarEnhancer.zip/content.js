// content.js

function createCopyButton(productNumber) {
    const button = document.createElement('button');
    button.className = 'lekolar-copy-btn';
    button.innerHTML = `
        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-copy"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path></svg>
        <span class="tooltip">Copy product number</span>
    `;

    button.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        navigator.clipboard.writeText(productNumber).then(() => {
            const tooltip = button.querySelector('.tooltip');
            const originalText = tooltip.innerText;
            tooltip.innerText = 'Copied!';
            tooltip.classList.add('visible');
            setTimeout(() => {
                tooltip.innerText = originalText;
                tooltip.classList.remove('visible');
            }, 2000);
        }).catch(err => {
            console.error('Failed to copy text: ', err);
        });
    });

    return button;
}

function findAndInject() {
    if (document.querySelector('.lekolar-copy-btn')) return;

    const xpath = "//*[contains(text(), 'Tuotenro')]";
    const result = document.evaluate(xpath, document, null, XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null);

    for (let i = 0; i < result.snapshotLength; i++) {
        const element = result.snapshotItem(i);
        const text = element.textContent.trim();

        // Case 1: "Tuotenro: 12345" in this element
        let match = text.match(/Tuotenro:?\s*([\d-]+)/i); // Added hyphen support just in case, and optional colon
        if (match) {
            const productNumber = match[1];
            element.appendChild(createCopyButton(productNumber));
            return;
        }

        // Case 2: "Tuotenro" here, number in next sibling
        if (text.match(/Tuotenro/i)) {
            let next = element.nextSibling;
            // Skip empty text nodes or comments
            while (next && (next.nodeType === 8 || (next.nodeType === 3 && !next.textContent.trim()))) {
                next = next.nextSibling;
            }

            if (next && next.textContent) {
                const nextText = next.textContent.trim();
                // Check if next text starts with number
                const numberMatch = nextText.match(/^:?\s*([\d-]+)/);
                if (numberMatch) {
                    const productNumber = numberMatch[1];
                    const btn = createCopyButton(productNumber);
                    // If next is an element, append to it or after it
                    if (next.nodeType === 1) { // Element
                        next.appendChild(btn);
                    } else { // Text node
                        // Append to parent, likely right after the text node
                        if (next.nextSibling) {
                            next.parentNode.insertBefore(btn, next.nextSibling);
                        } else {
                            next.parentNode.appendChild(btn);
                        }
                    }
                    return;
                }
            }
        }
    }
}

// Run initially
findAndInject();

// Run on mutations in case it's a SPA or loads dynamically
const observer = new MutationObserver((mutations) => {
    findAndInject();
});

observer.observe(document.body, {
    childList: true,
    subtree: true
});
